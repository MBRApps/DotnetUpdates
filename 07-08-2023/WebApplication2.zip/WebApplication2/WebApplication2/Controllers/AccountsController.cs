﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class AccountsController : Controller
    {
        // GET: Accounts
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(User user)
        {
            if(ModelState.IsValid)
            {
                using (TestContext db=new TestContext())
                {
                    db.Users.Add(user);
                    if(db.SaveChanges()>0)
                    {
                        return RedirectToAction("Login", "Accounts");
                    }
                }
            }
            return View();
        }


        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(UserLogin login)
        {
            if(ModelState.IsValid)
            {
                using (TestContext db=new TestContext())
                {
                    var users= db.Users.Where(x => x.Email == login.Email && x.Password == login.Password).ToList();
                    if(users.Count>0)
                    {
                        return RedirectToAction("Index", "Dashboard");
                    }
                    else
                    {
                        //implement message
                    }
                }
            }
            return View();
        }
    }
}