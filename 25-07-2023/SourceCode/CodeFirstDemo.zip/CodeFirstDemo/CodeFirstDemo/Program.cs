﻿using CodeFirstDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstDemo
{
    internal class Program
    {
        static void Insert()
        {
            using (StoreContext db=new StoreContext())
            {
                Product prod = new Product()
                {
                    Name="Iphone 14",
                    Price=96500
                };
                db.Products.Add(prod);
                if(db.SaveChanges()>0)
                {
                    Console.WriteLine("Inserted Successfully!");
                }
                else
                {
                    Console.WriteLine("Failed to Insert");
                }
            }
        }
        static void Main(string[] args)
        {
            Insert();
        }
    }
}
