﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ProductsController : Controller
    {
        public static List<Item> ProductList= new List<Item>()
            {
                new Item{Id=1,Title="Dell 3525",Price=38500 },
                new Item{Id=2,Title="Lenovo G80-50",Price=60500 },
                new Item{Id=3,Title="Iphone 13 Pro",Price=70000 },
                new Item{Id=4,Title="Redmi Pad 6",Price=28500 }
            };

        // GET: Products
        public ActionResult Index()
        {
            return View(ProductList);
        }

        [HttpGet]
        public ActionResult Add()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Add(Item item)
        {
            item.Id= ProductList.Max(x => x.Id) + 1;
            ProductList.Add(item);
            return RedirectToAction("Index","Products");
            
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            Item item= ProductList.Where(x => x.Id == id).FirstOrDefault();
            return View(item);
        }

        [HttpPost]
        public ActionResult Edit(Item item)
        {
            Item Dbitem = ProductList.Where(x => x.Id == item.Id).FirstOrDefault();
            Dbitem.Title = item.Title;
            Dbitem.Price = item.Price;
            return RedirectToAction("Index", "Products");

        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            Item item = ProductList.Where(x => x.Id == id).FirstOrDefault();
            ProductList.Remove(item);
            return RedirectToAction("Index", "Products");
        }
    }
}