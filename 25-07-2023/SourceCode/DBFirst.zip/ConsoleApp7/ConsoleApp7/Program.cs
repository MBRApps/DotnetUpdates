﻿using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    internal class Program
    {
        static void Insert()
        {
            Console.WriteLine("Enter Name:");
            string _name = Console.ReadLine();

            Console.WriteLine("Enter Age:");
            int _age = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter City:");
            string _city = Console.ReadLine();


            using (DBEntities db = new DBEntities())
            {
                user us = new user()
                {
                    name = _name,
                    age = _age,
                    city = _city,
                    createdBy = "System",
                    createdOn = DateTime.Now
                };
                db.users.Add(us);
                int rows = db.SaveChanges();
                if (rows > 0)
                {
                    Console.WriteLine($"{rows} Row(s) Inserted Successfully!");
                }
                else
                {
                    Console.WriteLine("Failed to Insert!");
                }

            }
        }

        static void GetData()
        {
            using (DBEntities db = new DBEntities())
            {
                foreach (var x in db.users.ToList())
                {
                    Console.WriteLine($"{x.id} - {x.name} - {x.age} - {x.city}");
                }
            }
        }

        static void Update()
        {
            Console.WriteLine("Enter Id:");
            int _id = int.Parse(Console.ReadLine());

            using (DBEntities db = new DBEntities())
            {
                user us = db.users.Find(_id);
                if (us != null)
                {
                    Console.WriteLine($"Existing Name is:{us.name}\nEnter Updated Name:");
                    us.name = Console.ReadLine();

                    Console.WriteLine($"Existing Age is:{us.age}\nEnter Updated Age:");
                    us.age = int.Parse(Console.ReadLine());

                    Console.WriteLine($"Existing City is:{us.city}\nEnter Updated City:");
                    us.city = Console.ReadLine();

                    int recCount = db.SaveChanges();
                    if (recCount > 0)
                    {
                        Console.WriteLine($"{recCount} Row(s) are updated successfully");
                    }
                    else
                    {
                        Console.WriteLine("Failed!");
                    }

                }
                else
                {
                    Console.WriteLine($"No Data Found with Id:{_id}");
                }
            }
        }

        static void Delete()
        {
            Console.WriteLine("Enter Id:");
            int _id = int.Parse(Console.ReadLine());

            using (DBEntities db = new DBEntities())
            {
                user us = db.users.Where(x => x.id == _id).FirstOrDefault();
                if (us != null)
                {
                    db.users.Remove(us);
                    int recCount= db.SaveChanges();
                    if(recCount>0)
                        Console.WriteLine($"{recCount} Row(s) are Deleted Successfully!");
                    else
                        Console.WriteLine("Failed to Delete");
                }
            }
        }
        static void Main(string[] args)
        {
            Delete();
            Console.ReadKey();
        }
    }
}
