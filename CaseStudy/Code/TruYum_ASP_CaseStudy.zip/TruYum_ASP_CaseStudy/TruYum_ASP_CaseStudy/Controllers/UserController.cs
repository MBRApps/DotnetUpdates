﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TruYum_ASP_CaseStudy.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult Index()
        {
            List<MenuItem> MenuList = new List<MenuItem>();
            using (TruYumDBEntities db = new TruYumDBEntities())
            {
                MenuList = db.MenuItems.ToList();
            }
            return View(MenuList);
        }

        public ActionResult AddToCart(int id)
        {
            using (TruYumDBEntities db=new TruYumDBEntities())
            {
                var item = db.MenuItems.Find(id);
                if (item != null)
                {
                    CartDetail cart = new CartDetail()
                    {
                        UserId= Session["userid"].ToString(),
                        Name=item.Name,
                        price=item.Price,
                        Category=item.Category,
                        FreeDelivery=item.FreeDelivery,
                        EntryDate=DateTime.Now
                    };
                    db.CartDetails.Add(cart);
                    if(db.SaveChanges()>0)
                    {
                        return RedirectToAction("Index", "User");
                    }
                }
            }
                return View();
        }


        public ActionResult CartDetails()
        {
            List<CartDetail> cart = new List<CartDetail>();
            if(Session.Count>0)
            {
                if (Session["userid"]!=null)
                {
                    using (TruYumDBEntities db = new TruYumDBEntities())
                    {
                        var userid = Session["userid"].ToString();
                        cart = db.CartDetails.Where(x => x.UserId ==userid ).ToList();
                    }
                }
            }            

                return View(cart);
        }


        public ActionResult DeleteFromCart(int id)
        {
            using (TruYumDBEntities db=new TruYumDBEntities())
            {
                db.CartDetails.Remove(db.CartDetails.Find(id));
                db.SaveChanges();
                return RedirectToAction("CartDetails", "User");
            }
        }

        public ActionResult ClearCart()
        {
            using (TruYumDBEntities db = new TruYumDBEntities())
            {
                var userid = Session["userid"].ToString();
                var cartItems = db.CartDetails.Where(x => x.UserId == userid).ToList();
                db.CartDetails.RemoveRange(cartItems);
                db.SaveChanges();
                return RedirectToAction("CartDetails", "User");
            }
        }

    }
}