﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;
namespace ConsoleApp6
{
    internal class Program
    {
        static string GetConnection()
        {
            var config = new ConfigurationBuilder().SetBasePath(AppDomain.CurrentDomain.BaseDirectory).AddJsonFile("appsettings.json").Build();
            return config.GetConnectionString("dbconn");

        }
        static void Insert()
        {
            Console.WriteLine("Enter Name:");
            string _name = Console.ReadLine();

            Console.WriteLine("Enter Age:");
            int _age = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter City:");
            string _city = Console.ReadLine();

            using (SqlConnection conn = new SqlConnection(GetConnection()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                cmd.CommandText = "insert into users (name,age,city) values (@name,@age,@city)";
                cmd.Parameters.AddWithValue("@name", _name);
                cmd.Parameters.AddWithValue("@age", _age);
                cmd.Parameters.AddWithValue("@city", _city);

                int _rows = cmd.ExecuteNonQuery();
                if (_rows > 0)
                {
                    Console.WriteLine($"{_rows} Row(s) are Inserted Successfully!");
                    //Console.WriteLine(_rows+ "Row(s) are Inserted Successfully!");
                }
                else
                {
                    Console.WriteLine("Failed To Insert!");
                }

                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        static void Update()
        {
            Console.WriteLine("Enter Id:");
            int _id = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Name:");
            string _name = Console.ReadLine();

            Console.WriteLine("Enter Age:");
            int _age = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter City:");
            string _city = Console.ReadLine();

            using (SqlConnection conn = new SqlConnection(GetConnection()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                cmd.CommandText = "update users set name=@name,age=@age,city=@city where id=@id";
                cmd.Parameters.AddWithValue("@name", _name);
                cmd.Parameters.AddWithValue("@age", _age);
                cmd.Parameters.AddWithValue("@city", _city);
                cmd.Parameters.AddWithValue("@id", _id);

                int _rows = cmd.ExecuteNonQuery();
                if (_rows > 0)
                {
                    Console.WriteLine($"{_rows} Row(s) are Updated Successfully!");
                    //Console.WriteLine(_rows+ "Row(s) are Inserted Successfully!");
                }
                else
                {
                    Console.WriteLine("Failed To Update!");
                }

                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        static void Delete()
        {
            Console.WriteLine("Enter Id:");
            int _id = int.Parse(Console.ReadLine());
           
            using (SqlConnection conn = new SqlConnection(GetConnection()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                cmd.CommandText = "delete from users where id=@id";
                cmd.Parameters.AddWithValue("@id", _id);

                int _rows = cmd.ExecuteNonQuery();
                if (_rows > 0)
                {
                    Console.WriteLine($"{_rows} Row(s) are Deleted Successfully!");
                    //Console.WriteLine(_rows+ "Row(s) are Inserted Successfully!");
                }
                else
                {
                    Console.WriteLine("Failed To Delete/Invalid Id!");
                }

                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        static void GetRows()
        {
            using (SqlConnection conn = new SqlConnection(GetConnection()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                cmd.CommandText = "select count(*) from users";

                int rowcount=(int)cmd.ExecuteScalar();
                Console.WriteLine($"Total Rows Available:{rowcount}");

                if(conn.State==ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        static void GetDataConn()
        {
            using (SqlConnection conn = new SqlConnection(GetConnection()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                cmd.CommandText = "select * from users";

                GetRows();
                SqlDataReader dr= cmd.ExecuteReader();
                while(dr.Read())
                {
                    Console.WriteLine($"{dr["id"]}-{dr["name"]}-{dr["age"]}-{dr["city"]}");
                }
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }

            }
        }

        static void GetDataDisConn()
        {
            using (SqlConnection conn = new SqlConnection(GetConnection()))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                cmd.CommandText = "select * from users";

                GetRows();

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if(dt.Rows.Count>0)
                {
                    foreach(DataRow dr in dt.Rows)
                    {
                        foreach(DataColumn dc in dt.Columns)
                        {
                            Console.Write($"{dr[dc]}      ");
                        }
                        Console.WriteLine();
                    }
                }
                else
                {
                    Console.WriteLine("No Data Found!");
                }


            }
        }

        static void Main(string[] args)
        {
            bool x = true;
            while(x)
            {
                Console.WriteLine("1.Insert\n2.Update\n3.Delete\n4.Get Data\n0.Exit\nEnter Choice:");
                int n = int.Parse(Console.ReadLine());

                switch(n)
                {
                    case 1: Insert();break;
                    case 2: Update();break;
                    case 3: Delete();break;
                    case 4: GetDataDisConn();break;
                    case 0:x = false;break;

                }
            }
        }
    }
}