﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace WebApplication2.Models
{
    public class PinCodeValidate:ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            string inp = (string)value;
            return Regex.IsMatch(inp, "^[5]{1}[0-9]{5}$");
        }
    }
    public class User
    {
        public int Id { get; set; }

        [Required]
        [Display(Name ="First Name")]
        public string FirstName { get; set; }

        [Required(ErrorMessage ="Last Name is Required")]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required]
        [Range(18,50,ErrorMessage ="Age should be min 18 and max 50")]
        public int Age { get; set; }

        [Display(Name = "Phone No.")]
        [Required]
        [RegularExpression("^[6-9]{1}[0-9]{9}$",ErrorMessage ="Invalid Mobile No.")]
        public string ContactNumber { get; set; }

        [Required]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [MaxLength(25,ErrorMessage ="Should be below 25 Chars")]
        public string Password { get; set; }

        [Required]
        [Display(Name ="Confirm Password")]
        [DataType(DataType.Password)]
        [MaxLength(25, ErrorMessage = "Should be below 25 Chars")]
        [Compare("Password",ErrorMessage ="Password and Confirm Password should be same")]
        [NotMapped]
        public string ConfirmPassword { get; set; }

        [Required]
        [PinCodeValidate(ErrorMessage ="Incorrect PinCode")]
        public string Pincode { get; set; }
    }
}