﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TruYum_ASP_CaseStudy.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        public ActionResult Index()
        {
            List<MenuItem> MenuList = new List<MenuItem>();
            using (TruYumDBEntities db=new TruYumDBEntities())
            {
                MenuList= db.MenuItems.ToList();
            }
                return View(MenuList);
        }

        public  ActionResult EditMenuItem(int id)
        {
            MenuItem item = new MenuItem();
            using (TruYumDBEntities db=new TruYumDBEntities())
            {
                item=db.MenuItems.Find(id);
            }

           
                return View(item);
        }

        [HttpPost]
        public ActionResult EditMenuItem(MenuItem item)
        {
            using (TruYumDBEntities db=new TruYumDBEntities())
            {
                var Menu= db.MenuItems.Find(item.mid);
                Menu.Name = item.Name;
                Menu.Category = item.Category;
                Menu.Price = item.Price;
                Menu.FreeDelivery = item.FreeDelivery;
                Menu.Active = item.Active;
                Menu.EntryDate = DateTime.Now;

                if(db.SaveChanges()>0)
                {
                    return RedirectToAction("Index", "Admin");
                }

            }
                return View();
        }
    }
}