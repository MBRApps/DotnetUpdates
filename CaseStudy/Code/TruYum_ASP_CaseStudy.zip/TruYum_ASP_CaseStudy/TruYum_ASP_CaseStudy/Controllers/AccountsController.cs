﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TruYum_ASP_CaseStudy.Models;

namespace TruYum_ASP_CaseStudy.Controllers
{
    public class AccountsController : Controller
    {
        // GET: Accounts
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(UserLogin login)
        {
            using (TruYumDBEntities db=new TruYumDBEntities())
            {
                UserMaster um=db.UserMasters.Where(x=>x.UserId==login.UserId && x.Password==login.Password).FirstOrDefault();
                if(um!=null)
                {
                    Session["name"] = um.FullName;
                    Session["userid"] = um.UserId;
                    Session["Role"] = um.Role;
                    if(um.Role==1)
                    {
                        return RedirectToAction("Index", "Admin");
                    }
                    else if(um.Role==2)
                    {
                        return RedirectToAction("Index", "User");
                    }
                }
                else
                {
                    TempData["msg"] = "Incorrect UserId/Password";
                }
            }
                return View();
        }


        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Login", "Accounts");
        }
    }
}